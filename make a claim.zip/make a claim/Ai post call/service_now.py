from io import BytesIO, StringIO
from typing import List, Dict, Text, Tuple, Callable
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
'''
add custom modules to import
'''
import glob
from PIL import Image
import io
import urllib.request
import webbrowser
import requests
import random
import json
import os 
import base64
from datetime import datetime
##custom class name
class Ticket_Creation():
    def __init__(self):
        pass

    def execute(self, stage: Dict, user_query: Text, entity_dict: Dict, system_entity_dict: Dict, variable_dict: Dict, response: Text ="") -> Tuple[str, dict, dict, str, str, bool]:
        is_fulfilment_success = True
        mandatory_ent_dict = {} ####
        end_conversation = 'Y'
        output_context = ''
        description=''
        try:
            # Code for creating a ticket in Snow for VPN gateway missing resolution
            # Varible list
                         
            print("************system entities dict -> {} *************************".format(system_entity_dict))   
            print("************entities dict -> {} *************************".format(entity_dict))
            
            file = entity_dict.get("_ATTACHMENTS",'file not found')
            response = file[0]
            
            url="https://car-damage-detection-wlq6d24rcq-ue.a.run.app/inference"
            with open(response, 'rb') as img:
              name_img= os.path.basename(response)
              files= {'image': (name_img,img,'multipart/form-data') }
              data = requests.post(url,files=files)
              data1=data.content
              res=json.loads(data1)
              #resp=res["status"]
              damage=res["classification"][0]["class_name"]
              imagepath=res["classification"][0]["image_path"]
              
              fullimagepath="https://car-damage-detection-wlq6d24rcq-ue.a.run.app/" + imagepath

            
              
            image = f"<img src={fullimagepath}>"


            #   response="Damage Identified : "+ damage +" and  "+"    "+"  Image_url : " + fullimagepath
            if damage == "small dent":
                response= f" Damage identified as "+damage+" <br><br> " + image +" <br><br> "+ "Estimated damage repairing cost is $247 "
            else:
                response=f" Damage identified as "+damage+" <br><br> " + image +" <br><br> "+ "Estimated damage repairing cost is $563 "
                 
                  

               


        except Exception as e:
            # ########################################################################## #
            #######################             exception block                   #################
            #######################  to update output variables in case of error  #################
            is_fulfilment_success = False
            end_conversation = "Y"
            response = f"Exception : "+str(e)
            print(e)
            logger.debug('Exception in fulfillment code: ' + str(e))
            import traceback
            traceback.print_tb(e.__traceback__)

        return response, entity_dict, mandatory_ent_dict, output_context, end_conversation, is_fulfilment_success

 