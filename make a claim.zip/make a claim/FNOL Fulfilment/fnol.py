
from typing import List, Dict, Text, Tuple
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.FATAL)
'''
add custom modules to import
'''

from datetime import date
import sys
import requests
from requests.auth import HTTPBasicAuth

##custom class name
class ClaimCreator():
    def __init__(self):
        pass
   
    def execute(self, stage: Dict, user_query: Text, entity_dict: Dict, system_entity_dict: Dict) -> Tuple[Text, Dict, Dict, Text, Text]:
                
        # pdb.set_trace()                    
        response = ""
        mandatory_ent_dict = {} ####
        
        end_conversation = 'N'
        output_context = ""
        is_fulfilment_success = True

        try:
        
            

            print("system_entities_dict -> {}".format(system_entity_dict))

            
            print("entity_dict -> {}".format(entity_dict))

            addr=entity_dict["address"]
            street=addr.split(",")[0]
            city=addr.split(",")[1]
            State=addr.split(",")[2]
            zipcode=addr.split(",")[3]

            
            
            str_pno = entity_dict['policyno']
            str_date_reported = str(date.today())
            str_address = street
            str_city = city
            str_state = State
            str_incident = entity_dict['desc_incident']
            str_date = entity_dict['date']
            str_time = entity_dict['time']
            str_zipcode = zipcode
            
            
            
            
            print("extraction done")
            
                    

            
            data = {"sopExecJSON": {"sopName": "FNOL", "execSOPParamsData": {"Policynumber": str_pno,"DateReported": str_date_reported,"PolicyinfoAddress": str_address,"State":str_state,"City": str_city,  "url": "http://localhost/Suite_AFS.Claims/Desktop/HomePage/Default.aspx?src=%2fSuite_AFS.Claims%2fDesktop%2fHomePage%2fHomePage.aspx&StaticPulseMode=true&IframeMode=true&UserStateId=08D93F869129A7A9","LossDescription": str_incident,"DateofLoss": str_date,"Year": "2007","TimeOfLoss": str_time,"Model": "Audi A7","Zipcode": str_zipcode}, "requestHeaderData": { "userid": "sbsuperadmin"}, "requestRulesData": {}}}
            print("Call is gonna be made!")
            req = requests.post('https://35.208.123.208:8443/syntbotssm/rest/executeSOPBySOPNameInSync',json=data, auth=HTTPBasicAuth('sbsuperadmin', 'Med2O!sChnTn'), verify=False,timeout=None)
            print("Call was made!")
            print("request: " +str(req.content))

            
            
           
           
            print("response from the server -> {}, json -> {}".format(req.status_code, req.json()))

            if req.status_code <= 600:

                print("status code -> {}, json -> {}".format(req.status_code, req.json()))

               
                print("policynumber -> {} & datereported -> {} & address -> {} & city -> {} & state -> {} & incidentdetails -> {} & date -> {} & time -> {} &  zipcode -> {}".format(str_pno,str_date_reported,str_address,str_city,str_state,str_incident,str_date,str_time,str_zipcode))


                sys.exit("Claim request received.Claim details will be mailed to your registered email id shortly. Is there anything else that I can help you with?")
                response = f"Claim request has been received.Claim details will be mailed to your registered email id. Is there anything else that I can help you with?"

            else:
                print('Error in claim creation: ' + req.content)
                response = f"Thank you for providing the information. Not able to create the claim  due to "  + req.content
                is_fulfilment_success = False
                
            
            end_conversation = 'N'

                
        except Exception as e:
            response = f"Thank you for providing the information. Unable to create the claim due to " + str(e)
            is_fulfilment_success = False
            print('Exception in fulfillment code: ' + str(e))        
        
        return response, entity_dict, mandatory_ent_dict, output_context, end_conversation, is_fulfilment_success


