# from datetime import date

# x=str( date.today() )
# print(x)

# Account unlock fulfillment module

import random
import requests
from typing import List, Dict, Text, Tuple
import logging
import json
import re
import requests
import sys

from requests.models import Response
headers = {'Content-type': 'application/json', 'charset': 'utf-8'}
logger = logging.getLogger(__name__)
logger.setLevel(logging.FATAL)
'''
add custom modules to import
'''

# custom class name


class AccountUnlock():
    def __init__(self):
        pass
    # returns string and dictonary with new entity values
    # the method is standard and don't modify the name of the method

    def execute(self, stage: Dict, user_query: Text, entity_dict: Dict, system_entity_dict: Dict) -> Tuple[Text, Dict, Dict, Text, Text]:
        response= dict()
        is_fulfilment_success = True
        mandatory_ent_dict = {}
        total_sum = 0
        end_conversation = 'N'
        output_context = ''
        try:
            ###########################user code begins here##############################
            # ########################################################################## #
            def getResponse(url):
                response = requests.get(url)
                datastr = response.text
                data = json.loads(datastr)
                return data

            def getdetails(id):
                url = ("http://35.206.75.60:9090/api/v1/policy/"+id)
                return url

            p_no = entity_dict.get("policyno")  # "Line1000009"
            #print(p_no)
            #intent = entity_dict.get("intent")

            # if(intent == "know" or intent == "show" or intent == "see" or intent == "get" or intent == "what" or intent == "want my" or intent == "want" or intent == "fetch" or intent == "cancel" or intent == "claim" or intent == "date"):
            url = getdetails(p_no)
            data = getResponse(url)
            #print(data)
            
            userdetails ="Please verify your policy details:"+"<br><br>" + "Policy Number: "+ p_no + "<br><br>"+ "Policy Holder: "+ data["customerName"] + "<br><br>" +"Phone: " + str(data["customer"]["primaryPhoneNumber"]) + "<br><br>" +"Email Id: " +data["customer"]["email"]
            
            response['type']= "LIST_BUTTONS"
            response["button_text"] = userdetails +"<br><br>"
            response['button_values']= [{"button_label":"Confirm","button_payload":"Confirm"},{"button_label":"Update","button_payload":"Update"}]
            response['delegate']="N"
            # response = 'Testing'
            

            # response['type']= "LIST_BUTTONS"
            # response["button_text"] = user_msg+ " Do you want create another ticket ?"
            # response['button_values']= [{"button_label":"Yes","button_payload":"zta"},{"button_label":"No","button_payload":"No"}]

            # ########################################################################## #
            ###########################user code ends here##############################
        except Exception as e:
            # ########################################################################## #
            #######################             exception block                   #################
            #######################  to update output variables in case of error  #################
            is_fulfilment_success = False
            end_conversation = "N"
            response = f"Exception Occured: "+str(e)
            logger.debug('Exception in fulfillment code: ' + str(e))

        return response, entity_dict, mandatory_ent_dict, output_context, end_conversation, is_fulfilment_success
