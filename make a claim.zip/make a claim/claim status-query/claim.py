  # Hire fulfillment module

from typing import List, Dict, Text, Tuple
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.FATAL)
'''
add custom modules to import
'''
from datetime import datetime
import random

import pandas as pd

import pdb

import re
import requests
from requests.auth import HTTPBasicAuth

##custom class name
class ClaimStatus():
    def __init__(self):
        pass
    #returns string and dictonary with new entity values
    #the method is standard
    def execute(self, stage: Dict, user_query: Text, entity_dict: Dict, system_entity_dict: Dict) -> Tuple[Text, Dict, Dict, Text, Text]:
                
        # pdb.set_trace()                    
        response = ""
        mandatory_ent_dict = {} ####
        total_sum=0
        end_conversation = 'N'
        output_context = ""
        is_fulfilment_success = True

        try:
        ###########################user code starts here##############################
        # ########################################################################## #
            

            print("system_entities_dict -> {}".format(system_entity_dict))

            
            print("entity_dict -> {}".format(entity_dict))

            
            str_cno = entity_dict['ecno']


            
            print("extraction done")
            response = f"Your claim request has been received.<br><br>Claim status will be mailed to your registered email id.<br><br> Is there anything else that I can help you with?"

            #data = {"sopExecJSON": {"sopName": "SNOW_Tckt_Creation", "execSOPParamsData": {"name": str_name, "email": str_email_, "DAS_ID": did}, "requestHeaderData": {}, "requestRulesData": {}}}
            #data = {"sopExecJSON": {"sopName": "SNOW_Tckt_Creation", "execSOPParamsData": {"email": str_email, "DAS_ID": str_das}, "requestHeaderData": {}, "requestRulesData": {}}}
            data = {"sopExecJSON": {"sopName": "claimSOP", "execSOPParamsData": {"Claimnumber": str_cno,  "url": "http://localhost/Suite_AFS.Claims/Desktop/HomePage/Default.aspx?src=%2fSuite_AFS.Claims%2fDesktop%2fHomePage%2fHomePage.aspx&StaticPulseMode=true&IframeMode=true&UserStateId=08D93F869129A7A9"}, "requestHeaderData": { "userid": "sbsuperadmin"}, "requestRulesData": {}}}
            print("Call is gonna be made!")
            req = requests.post('https://35.208.123.208:8443/syntbotssm/rest/executeSOPBySOPNameInSync',json=data, auth=HTTPBasicAuth('sbsuperadmin', 'Med2O!sChnTn'), verify=False)
            print("Call was made!")
            print("request: " +str(req.content))

            cont = req.json()

            #ticket = cont['number']
           
           
            print("response from the server -> {}, json -> {}".format(req.status_code, req.json()))

            if req.status_code == 200:

                print("status code -> {}, json -> {}".format(req.status_code, req.json()))

                print("claimno -> {}".format(str_cno))


                # response=str(req.json())
                # response = f"Thank you for providing the information.Claim status will be mailed to your registered email id. Is there anything else that I can help you with?"

            else:
                print('Error in ticket creation: ' + req.content)
                response = f"Thank you for providing the information. Not able to get the claim status due to an error. Please try again after sometime. Is there anything else that I can help you with?"
                is_fulfilment_success = False
                
            
            end_conversation = 'N'

                # ########################################################################## #
    ###########################user code ends here##############################
        except Exception as e:
            response = f"Thank you for providing the information. Unable to get the claim status due to" + str(e)
            is_fulfilment_success = False
            print('Exception in fulfillment code: ' + str(e))        
        
        return response, entity_dict, mandatory_ent_dict, output_context, end_conversation, is_fulfilment_success

##method for testing fulfillment module.
###this method will not be called by the platform
 
